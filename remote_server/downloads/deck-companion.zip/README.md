# Game Assist Deck companion (source only)

Python 3.10+ standard library, venv, and a working systemctl --user session are
required. No pip packages, binaries, Steam passwords, or API keys are included.

On your own Steam Deck, enter Desktop Mode as the normal user (never sudo).
Extract this archive, inspect the source, then run from the extracted directory:

    python3 -m deck setup --server https://YOUR-CONFIGURED-SERVICE

Use the exact HTTPS origin shown by the service's /setup page, not this placeholder.
Explicitly select your save path. On your phone open the displayed pairing URL,
sign in with Steam, compare the code shown on your own Deck, and select the game
and permitted four-field summary. Approve only your own device. The setup asks
before enabling the user-only background service. No game saves are modified.

Do not disable SteamOS protections or install missing runtime components blindly.
If Python/venv/user-systemd are missing, stop and use a separately reviewed solution.
Gaming Mode persistence still needs real-Deck testing. Device pairing expires after
30 days. Summary fields are reported raw values, not max HP/mana or pickup proof.
This archive contains no account tokens, server state, saves or private fixtures.
Code license: MIT (see LICENSE). Third-party games are not included or licensed here.
